// JavaScript for handling theme and language settings

document.addEventListener('DOMContentLoaded', function() {
    // Apply theme based on user settings
    const userTheme = document.body.getAttribute('data-theme');
    if (userTheme === 'dark') {
        document.body.classList.add('dark-theme');
    } else {
        document.body.classList.remove('dark-theme');
    }

    // Handle theme toggle in settings page
    const themeRadios = document.querySelectorAll('input[name="theme"]');
    if (themeRadios.length > 0) {
        themeRadios.forEach(radio => {
            radio.addEventListener('change', function() {
                // This will be applied when the form is submitted
                console.log('Theme selected:', this.value);
            });
        });
    }

    // Handle language toggle in settings page
    const languageRadios = document.querySelectorAll('input[name="language"]');
    if (languageRadios.length > 0) {
        languageRadios.forEach(radio => {
            radio.addEventListener('change', function() {
                // This will be applied when the form is submitted
                console.log('Language selected:', this.value);
            });
        });
    }
});
