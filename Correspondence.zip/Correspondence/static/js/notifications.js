// نظام إدارة الإشعارات

document.addEventListener('DOMContentLoaded', function() {
    // التحقق من وجود قائمة الإشعارات
    const notificationsDropdown = document.getElementById('notificationsDropdown');
    if (!notificationsDropdown) return;

    const notificationsContainer = document.querySelector('.notifications-container');
    const notificationsBadge = document.querySelector('.notifications-badge');
    const notificationsCount = document.querySelector('.notifications-count');
    const noNotifications = document.querySelector('.no-notifications');
    const markAllReadBtn = document.querySelector('.mark-all-read');

    // دالة لتحديث عدد الإشعارات غير المقروءة
    function updateNotificationsCount() {
        fetch('/notifications/count')
            .then(response => response.json())
            .then(data => {
                if (data.count > 0) {
                    notificationsCount.textContent = data.count;
                    notificationsBadge.classList.remove('d-none');
                } else {
                    notificationsBadge.classList.add('d-none');
                }
            })
            .catch(error => console.error('Error:', error));
    }

    // دالة لتحميل الإشعارات
    function loadNotifications() {
        fetch('/api/notifications')
            .then(response => response.json())
            .then(data => {
                // إزالة الإشعارات القديمة
                const oldNotifications = notificationsContainer.querySelectorAll('.notification-item');
                oldNotifications.forEach(item => item.remove());

                if (data.notifications && data.notifications.length > 0) {
                    // إخفاء رسالة "لا توجد إشعارات"
                    noNotifications.classList.add('d-none');

                    // إضافة الإشعارات الجديدة
                    data.notifications.forEach(notification => {
                        const notificationItem = document.createElement('a');
                        notificationItem.href = notification.link || '#';
                        notificationItem.className = `notification-item ${notification.is_read ? '' : 'unread'}`;
                        notificationItem.dataset.id = notification.id;

                        const iconDiv = document.createElement('div');
                        iconDiv.className = `notification-icon bg-${notification.color}`;
                        iconDiv.innerHTML = `<i class="fas ${notification.icon}"></i>`;

                        const contentDiv = document.createElement('div');
                        contentDiv.className = 'notification-content';

                        const title = document.createElement('div');
                        title.className = 'notification-title';
                        title.textContent = notification.title;

                        const text = document.createElement('div');
                        text.className = 'notification-text';
                        text.textContent = notification.content;

                        const time = document.createElement('div');
                        time.className = 'notification-time';
                        time.textContent = new Date(notification.created_at).toLocaleString('ar-SA');

                        contentDiv.appendChild(title);
                        contentDiv.appendChild(text);
                        contentDiv.appendChild(time);

                        notificationItem.appendChild(iconDiv);
                        notificationItem.appendChild(contentDiv);

                        // إضافة معالج النقر لتعيين الإشعار كمقروء
                        notificationItem.addEventListener('click', function(e) {
                            if (!notification.is_read) {
                                markNotificationAsRead(notification.id);
                            }
                        });

                        notificationsContainer.appendChild(notificationItem);
                    });
                } else {
                    // إظهار رسالة "لا توجد إشعارات"
                    noNotifications.classList.remove('d-none');
                }

                // تحديث عدد الإشعارات غير المقروءة
                updateNotificationsCount();
            })
            .catch(error => console.error('Error:', error));
    }

    // دالة لتعيين إشعار كمقروء
    function markNotificationAsRead(id) {
        fetch(`/notifications/mark-read/${id}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // تحديث واجهة المستخدم
                const notification = document.querySelector(`.notification-item[data-id="${id}"]`);
                if (notification) {
                    notification.classList.remove('unread');
                }
                // تحديث عدد الإشعارات غير المقروءة
                updateNotificationsCount();
            }
        })
        .catch(error => console.error('Error:', error));
    }

    // دالة لتعيين كل الإشعارات كمقروءة
    function markAllNotificationsAsRead() {
        fetch('/notifications/mark-all-read', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // تحديث واجهة المستخدم
                const unreadNotifications = document.querySelectorAll('.notification-item.unread');
                unreadNotifications.forEach(item => item.classList.remove('unread'));
                // تحديث عدد الإشعارات غير المقروءة
                notificationsBadge.classList.add('d-none');
            }
        })
        .catch(error => console.error('Error:', error));
    }

    // إضافة معالج النقر لزر "تعيين الكل كمقروء"
    if (markAllReadBtn) {
        markAllReadBtn.addEventListener('click', markAllNotificationsAsRead);
    }

    // تحميل الإشعارات عند فتح القائمة المنسدلة
    notificationsDropdown.addEventListener('click', function() {
        loadNotifications();
    });

    // تحديث عدد الإشعارات غير المقروءة عند تحميل الصفحة
    updateNotificationsCount();

    // تحديث عدد الإشعارات كل دقيقة
    setInterval(updateNotificationsCount, 60000);
});
